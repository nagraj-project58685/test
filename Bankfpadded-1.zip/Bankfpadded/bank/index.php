<?php
// Homepage
header('Location: pages/home.php');
exit;